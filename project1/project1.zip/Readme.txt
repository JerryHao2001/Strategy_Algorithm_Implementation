1. CSC 242

2. Project 1 (Tic-tac-toe)

3. Jiayi Hao 31727716 (jhao3@u.rochester.edu)

4. Group members
Shiyu Liu 31726955 (sliu89@u.rochester.edu)
Erjia Meng 31727297 (emeng2@u.rochester.edu)

5. Running Instructions
(1) First, start command-line at the folder where the source codes located.
(2) compile and run with the code below: 

javac *.java
java Tictactoe

(3) expect results are as below (copied from the command-line)

D:\JerryHao\Documents\UOR\Sophomore\DSCC242\Project\project1>javac *.java

D:\JerryHao\Documents\UOR\Sophomore\DSCC242\Project\project1>java Tictactoe
Choose your game:
1. Basic 3x3 Tic-tac-toe
2. Nine-board Tic-tac-toe
Your Choice?
2
Starting Nine-board Tic-tac-toe
Do you want to play X or O?
...

After choosing the game type and role, the game will start. Have fun! ; )


